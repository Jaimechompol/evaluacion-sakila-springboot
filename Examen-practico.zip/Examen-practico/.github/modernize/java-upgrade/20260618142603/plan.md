# Upgrade Plan: sakila-api (20260618142603)

- **Generated**: June 18, 2026, 14:26:03
- **HEAD Branch**: N/A (Git not available)
- **HEAD Commit ID**: N/A (Git not available)

> Note: Version control operations are not available in this workspace as it is not a git repository. Changes will remain uncommitted in the working directory.

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 21: **<TO_BE_INSTALLED>** (required by upgrade steps)
- JDK 25.0.2: C:\Program Files\Java\jdk-25.0.2\bin (available but not used)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (required for compilation and testing)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (not a git repository)
- Run tests before and after the upgrade: true

## Upgrade Goals

- **Java**: 17 → 21

## Technology Stack

| Technology/Dependency    | Current | Min Compatible | Why Incompatible |
| ------------------------ | ------- | -------------- | ----------------------------------------- |
| Java                     | 17      | 21             | User requested                            |
| Spring Boot              | 3.2.8   | 3.2.8          | Compatible with Java 21; no upgrade needed |
| Spring Framework         | 6.1.x   | 6.1.x          | Compatible with Java 21                   |
| mysql-connector-j        | latest  | latest         | Compatible with Java 21                   |
| springdoc-openapi        | 2.2.0   | 2.2.0          | Compatible with Java 21                   |
| Spring Data JPA          | 3.2.x   | 3.2.x          | Compatible with Java 21                   |
| Tomcat (embedded)        | 10.1.x  | 10.1.x         | Compatible with Java 21                   |

## Derived Upgrades

- Java 21 requires Maven 3.9+ recommended (current system has no Maven; will install 3.9.x)
- No dependency version upgrades needed; Spring Boot 3.2.8 is fully compatible with Java 21

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version property | 17 | upgrade | 21 | User requested Java 21 target |

### Subsection: Source Code Changes

No source code changes required. Spring Boot 3.2.8 and Java 21 are compatible; no API deprecations or breaking changes affecting this codebase.

### Subsection: Configuration Changes

No configuration changes required in application.properties or application.yml.

### Subsection: CI/CD Changes

No CI/CD files detected in project (no Dockerfile, azure-pipelines.yml, or GitHub Actions workflows).

### Subsection: Risks & Warnings

- **Module system strictness**: Java 21 enforces stronger encapsulation. If the codebase uses reflection to access internal JDK classes (e.g., `sun.misc.*`, `jdk.internal.*`), compilation or runtime errors may occur. Current scan shows no such usage in the visible codebase. Verify at runtime if any third-party libraries use illegal reflection.
- **Serialization changes**: Java 21 may have subtle serialization format changes. Existing serialized data (if any) should be validated post-upgrade. No evidence in codebase.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install required build tools (Maven 3.9.x) and Java 21 JDK to support compilation and testing
  - **Changes to Make**: Install Maven 3.9.x and Java 21 JDK using system package managers or provided installation tools
  - **Verification**: `mvn --version` (Maven 3.9+), `java -version` (Java 21), `javac -version` (Java 21)

- Step 2: Setup Baseline
  - **Rationale**: Establish baseline test results before upgrade; skip if base Java 17 JDK unavailable
  - **Changes to Make**: None (record baseline only)
  - **Verification**: Skipped (base JDK 17 not available on system)

- Step 3: Upgrade Java Version in pom.xml
  - **Rationale**: Update the `java.version` property to target Java 21 LTS
  - **Changes to Make**: Update `<java.version>17</java.version>` to `<java.version>21</java.version>` in pom.xml
  - **Verification**: `mvn clean test-compile -q` with Java 21 JDK (compilation must succeed)

- Step 4: Final Validation
  - **Rationale**: Verify all compilation and tests pass with Java 21; achieve 100% test pass rate
  - **Changes to Make**: None (verification only)
  - **Verification**: `mvn clean test -q` with Java 21 JDK (all tests must pass)

- Step 5: CVE Validation & Fix (if needed)
  - **Rationale**: Scan upgraded dependencies for known CVEs and fix if found
  - **Changes to Make**: Upgrade any vulnerable dependency versions if CVEs are reported
  - **Verification**: `#appmod-validate-cves-for-java` scan; re-scan after fixes applied
