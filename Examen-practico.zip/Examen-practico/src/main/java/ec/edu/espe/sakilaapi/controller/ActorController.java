package ec.edu.espe.sakilaapi.controller;

import ec.edu.espe.sakilaapi.entity.Actor;
import ec.edu.espe.sakilaapi.service.ActorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/actores")
public class ActorController {

    private final ActorService actorService;

    public ActorController(ActorService actorService) {
        this.actorService = actorService;
    }

    @GetMapping
    public List<Actor> listarActores() {
        return actorService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Actor> obtenerActor(@PathVariable Short id) {
        return ResponseEntity.ok(actorService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<Actor> crearActor(@Valid @RequestBody Actor actor) {
        Actor nuevo = actorService.guardar(actor);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Actor> actualizarActor(@PathVariable Short id, @Valid @RequestBody Actor actor) {
        return ResponseEntity.ok(actorService.actualizar(id, actor));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarActor(@PathVariable Short id) {
        actorService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/buscar")
    public List<Actor> buscarPorApellido(@RequestParam String apellido) {
        return actorService.buscarPorApellido(apellido);
    }
}
