package ec.edu.espe.sakilaapi.service;

import ec.edu.espe.sakilaapi.entity.Film;
import ec.edu.espe.sakilaapi.exception.ResourceNotFoundException;
import ec.edu.espe.sakilaapi.repository.FilmRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class FilmService {

    private final FilmRepository filmRepository;

    public FilmService(FilmRepository filmRepository) {
        this.filmRepository = filmRepository;
    }

    public List<Film> listarTodas() {
        return filmRepository.findAll();
    }

    public Film buscarPorId(Short id) {
        return filmRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pelicula no encontrada con id: " + id));
    }

    public List<Film> buscarPorTitulo(String titulo) {
        return filmRepository.findByTitleContainingIgnoreCase(titulo);
    }
}
