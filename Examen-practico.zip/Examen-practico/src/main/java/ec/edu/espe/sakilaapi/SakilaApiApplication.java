package ec.edu.espe.sakilaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SakilaApiApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(SakilaApiApplication.class, args);
    }
}
