package ec.edu.espe.sakilaapi.repository;

import ec.edu.espe.sakilaapi.entity.Film;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FilmRepository extends JpaRepository<Film, Short> {
    List<Film> findByTitleContainingIgnoreCase(String title);
}
