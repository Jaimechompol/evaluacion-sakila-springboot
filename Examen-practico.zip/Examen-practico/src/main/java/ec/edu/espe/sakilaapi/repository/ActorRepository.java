package ec.edu.espe.sakilaapi.repository;

import ec.edu.espe.sakilaapi.entity.Actor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActorRepository extends JpaRepository<Actor, Short> {
    List<Actor> findByLastNameContainingIgnoreCase(String lastName);
}
