package ec.edu.espe.sakilaapi.controller;

import ec.edu.espe.sakilaapi.entity.Film;
import ec.edu.espe.sakilaapi.service.FilmService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/peliculas")
public class FilmController {

    private final FilmService filmService;

    public FilmController(FilmService filmService) {
        this.filmService = filmService;
    }

    @GetMapping
    public List<Film> listarPeliculas() {
        return filmService.listarTodas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Film> obtenerPelicula(@PathVariable Short id) {
        return ResponseEntity.ok(filmService.buscarPorId(id));
    }

    @GetMapping("/buscar")
    public List<Film> buscarPorTitulo(@RequestParam String titulo) {
        return filmService.buscarPorTitulo(titulo);
    }
}
