package ec.edu.espe.sakilaapi.service;

import ec.edu.espe.sakilaapi.entity.Actor;
import ec.edu.espe.sakilaapi.exception.ResourceNotFoundException;
import ec.edu.espe.sakilaapi.repository.ActorRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class ActorService {

    private final ActorRepository actorRepository;

    public ActorService(ActorRepository actorRepository) {
        this.actorRepository = actorRepository;
    }

    public List<Actor> listarTodos() {
        return actorRepository.findAll();
    }

    public Actor buscarPorId(Short id) {
        return actorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Actor no encontrado con id: " + id));
    }

    public Actor guardar(@Valid Actor actor) {
        actor.setLastUpdate(LocalDateTime.now());
        return actorRepository.save(actor);
    }

    public Actor actualizar(Short id, @Valid Actor actor) {
        Actor existente = buscarPorId(id);
        existente.setFirstName(actor.getFirstName());
        existente.setLastName(actor.getLastName());
        existente.setLastUpdate(LocalDateTime.now());
        return actorRepository.save(existente);
    }

    public void eliminar(Short id) {
        Actor existente = buscarPorId(id);
        actorRepository.delete(existente);
    }

    public List<Actor> buscarPorApellido(String apellido) {
        return actorRepository.findByLastNameContainingIgnoreCase(apellido);
    }
}
