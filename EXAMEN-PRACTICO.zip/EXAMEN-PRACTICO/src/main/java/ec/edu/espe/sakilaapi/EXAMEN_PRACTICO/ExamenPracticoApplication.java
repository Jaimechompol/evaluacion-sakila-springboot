package ec.edu.espe.sakilaapi.EXAMEN_PRACTICO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenPracticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenPracticoApplication.class, args);
	}

}
