package ec.edu.espe.sakilaapi.EXAMEN_PRACTICO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenPracticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
